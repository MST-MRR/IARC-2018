#!/usr/bin/env python3.5
# -------------------------------------------------------------------------
# Multi-Rotor Robot Design Team
# Missouri University of Science and Technology
# Fall 2017
# Christopher O'Toole
# -------------------------------------------------------------------------

from . import obj_detect

__version__ = '1.0.5'